const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");
const loginButton = document.querySelector('.btn.solid');

sign_up_btn.addEventListener("click", () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener("click", () => {
  container.classList.remove("sign-up-mode");
});

// Redirect to home page on login
document.getElementById('sign-up-btn').addEventListener('click', function() {
  window.location.href = 'loan.html'; 
});
loginButton.addEventListener('click', function() {
  window.location.href = 'loan.html';
});

sign_in_btn.addEventListener('click', () => {
  window.location.href = 'home.html';
});
sign_up_btn.addEventListener('click', () => {
  window.location.href = 'home.html';
});
